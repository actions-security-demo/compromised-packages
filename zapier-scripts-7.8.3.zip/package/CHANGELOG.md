# CHANGELOG

## vNext

## 7.8.1

- Fix `fetch-mock` warnings in Jest tests.

## 7.8.0

- Upgrade `@zapier/babel-preset-zapier` to v6.3.0 from v6.2.0, which updates all babel packages it uses to latest.

## 7.7.1

- Fix error when trying to format files that don't exist

## v7.7.0

- Upgrade `@zapier/babel-preset-zapier` to v6.2.0 from v6.0.0, which adds support for nullish-coalescing operator and optional chaining syntax.

## v7.6.2

- Fix unhandled promise in `format` command

## v7.6.1

- Improve Jest's default config so that `transformIgnorePatterns` more eagerly transforms `@zapier/*` packages in `node_modules/`.

## v7.6.0

- Remove support for formatting yaml files. More work is needed to unify code formatting across front and backend.

## v7.5.0

- Add support for formatting yaml files

## v7.4.4

- Add support for ESNext in Typescript

## v7.4.3

- Version bump caused by failed experiment with `lerna publish` - NO CHANGES

## v7.4.2

- Version bump caused by failed experiment with `lerna publish` - NO CHANGES

## v7.4.1

- Fix regression: quote file globs passed to Prettier, which makes sure Prettier expands the globs rather than the shell. This prevents some files from being skipped when running format in non-CI mode.

## v7.4.0

- On a CI environment, if the `GIT_CHANGED_FILES` environment variable is present, the `format` script will only check formatting of those files. This allows the check to run much faster. The `GIT_CHANGED_FILES` env var needs to have the following format for this to work: `file1:file2:file3`.

## v7.3.0

- Update Husky from v0.x.x to v1.x

## v7.2.0

- Update React testing library to latest version (v9.1.1)
- Update React & React DOM to latest version (v16.9.0)
- Remove react-testing-library/cleanup-after-each since it is [automatic now](https://github.com/testing-library/react-testing-library/releases/tag/v9.0.0)

## v7.1.0

- Upgrade Jest-DOM to latest version (v4.0.0)

## v7.0.0

- Apply Prettier to all Markdown files.
- Update Jest version to v24.8.0
- Update Jest config to include: jest-dom/extend-expect, react-testing-library/cleanup-after-each, and fetchMock.reset()

## v6.2.0

- Upgrade Prettier to latest version (v1.16.4)

## v6.1.0

- Use a React component to mock `SVG`s.
- Make sure tests use the `UTC` timezone.

## v6.0.1

- Add additional pattern to `transformIgnorePatterns` so that it picks up some missing packages

## v6.0.0

- Bump `@zapier/eslint-plugin-zapier` to `9.0.0`. This version enables new React Hooks rules by default, so it's considered a breaking change.

## v5.1.0

- Add new `validate` command, which runs `test`, `lint`, and `format` in parallel and pretty-prints the output.

## v5.0.0

- Update `@zapier/babel-preset-zapier` to `8.0.0`. This version enables new a11y rules by default, so it's considered a breaking change.

## v4.3.0

_(Published as minor due to an earlier tagging mistake)_

- Bump `@zapier/babel-preset-zapier` to `5.2.2`.

## v4.2.0

- Bump `@zapier/babel-preset-zapier` to `5.2.0` and expose a new `target` option.

## v4.1.1

- Bump `@zapier/babel-preset-zapier` to `5.1.0`.

## v4.1.0

- Polyfill `require.context` in a Jest environment.
- Give an ESLint `node` environment to files matching `*.config*`.

## v4.0.2

- Ignore the `build/` folder when running tests.

## v4.0.1

- Do not exit with a status 1 when no tests are present.
- Fix @zapier dependencies not being transpiled in the monorepo.

## v4.0.0

- Update `babel-preset-zapier`, `enzyme-adapter-react-16`, `jest`, `raf`, `react`, `react-dom`.

## v3.4.1

- Fix linting env for \*.test.js

## v3.4.0

- Add support for using test files anywhere with naming pattern \*.test.js
- Bump React dependency to 16.6

## v3.3.0

- Bump enzyme dependencies for better React 16.3+ compatibility

## v3.2.0

- Add `is-ci` package to automatically detect if CI is running script
- Remove `--ci` flag from format script in favor of `is-ci` package
- Upgrade `prettier` version to 1.14.2 to match `@zapier/zapier`

## v3.1.1

- Fixed `zapier-scripts test` not ignoring the `node_modules` folder at the root of monorepos

## v3.1.0

- Added default mocks for `localStorage`, `indexedDB`, `fetch`, `matchMedia` and `document.cookie` when running `zapier-scripts test`.

## v3.0.1

- Fixed scripts not running properly on yarn workspaces [PR#14](https://github.com/zapier/zapier-scripts/pull/14)
- Fix `zapier-scripts test` not working properly with `zapier-ui` packages [PR#15](https://github.com/zapier/zapier-scripts/pull/15)
