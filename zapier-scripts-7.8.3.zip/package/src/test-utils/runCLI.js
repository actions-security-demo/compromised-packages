const { spawnSync } = require('child_process');
const CLI_PATH = require.resolve('../../src');

export default function runCLI(args = [], cwd = null) {
  const options = {
    cwd,
    env: {
      ...process.env,
      NODE_NO_WARNINGS: 1,
      Z_TELEMETRY_DISABLED: 1,
    },
  };

  const result = spawnSync('node', [CLI_PATH, ...args], options);

  return {
    output: result.output.join(''),
    exitCode: result.status,
  };
}
