import fs from 'fs';
import path from 'path';

import rimraf from 'rimraf';
import tmp from 'tmp';

import runCLI from './runCLI';

// A helper class to run integration tests in an isolated fake fixture project.
//
// Usage:
//
// ```
// const fixtureProjectTester = new FixtureProjectTester();
// fixtureProjectTester.runCLI('lint', {
//   tests: [
//     '/path/to/fixture-file.js'
//   ],
//   // Use '.' to represent files at the project root.
//   '.': [
//     '/path/to/another-file.js'
//   ],
// });
// ```
//
// This will create a fake project with the following folder structure:
//  /tmp/zapier-scripts-3p5e6T/
//  ├── package.json
//  ├── another-file.js
//  └── tests
//      └── fixture-file.js
// And return an object with `exitCode` and `output` keys.
//
// Use `cleanUp` to clean-up the fixture project that was created after you're done:
// ```
// fixtureProjectTester.cleanUp();
// ```
export default class FixtureProjectTester {
  tmpFolders = [];

  makeFromRepresentation(representation) {
    const rootFolder = tmp.dirSync({ template: '/tmp/zapier-scripts-XXXXXX' });
    const rootFolderPath = rootFolder.name;

    this.tmpFolders.push(rootFolderPath);

    // Create a fake package.json so zapier-scripts can detect the root of our project properly
    const packageJson = require.resolve('../../fixtures/fake-package.json');
    fs.copyFileSync(packageJson, path.join(rootFolderPath, 'package.json'));

    // symlink node_modules folder so we get all the `.bin`s that come with `zapier-scripts` on
    // a real project
    fs.symlinkSync(
      path.join(__dirname, '../../../../../node_modules/'),
      path.join(rootFolderPath, 'node_modules'),
      'dir'
    );

    Object.keys(representation).forEach(folderName => {
      const folderPath = path.join(rootFolderPath, folderName);
      // If folderName is `.`, we don't need to create it.
      if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath);
      }

      const folderContents = representation[folderName];
      if (!Array.isArray(folderContents)) {
        throw new Error(
          `content of folder ${folderName} must be an array of file paths`
        );
      }

      folderContents.forEach(file => {
        if (!fs.existsSync(file)) {
          throw new Error(`path provided as fixture does not exist: ${file}`);
        }

        fs.copyFileSync(file, path.join(folderPath, path.basename(file)));
      });
    });

    return rootFolderPath;
  }

  cleanUp() {
    this.tmpFolders.forEach(f => rimraf.sync(f));
  }

  runCLI(args = [], fakeProjectRepresentation = null) {
    if (!fakeProjectRepresentation) {
      return runCLI(args);
    }

    const fakeProjectRootPath = this.makeFromRepresentation(
      fakeProjectRepresentation
    );
    const result = runCLI(args, fakeProjectRootPath);

    return {
      ...result,
      // Normalize the output to remove the reference to the fixture project path.
      // If we didn't do this snapshot tests would never pass, since everytime it runs
      // a tmp-dir with a different name is created.
      output: result.output.replace(
        /\/(.*)\/zapier-scripts-.{6}/,
        'zapier-scripts'
      ),
    };
  }
}
