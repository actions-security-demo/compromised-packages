#! /usr/bin/env node

const path = require('path');
const execa = require('execa');
const Listr = require('listr');

// TODO(vitorbal): add a `--changedSince <branch>` flag so you can validate only
// changes in your branch since <branch>

const makeTaskRunner = taskName => async () =>
  execa('node', [path.join(__dirname, taskName), '--color']);

const tasks = [
  {
    title: '🕵🏼  Linting files',
    task: makeTaskRunner('lint'),
  },
  {
    title: '🔬  Running tests',
    task: makeTaskRunner('test'),
  },
  {
    title: '💅  Checking code formatting',
    task: makeTaskRunner('format'),
  },
];

const logErrors = error => {
  if (Array.isArray(error.errors)) {
    error.errors.forEach(lintError => {
      console.error(lintError.message);
    });
  } else {
    console.error(error.message);
  }
};

const validate = async () => {
  const listr = new Listr(tasks, { concurrent: true, exitOnError: true });

  return listr.run().catch(error => {
    // Don't log errors if we're not in TTY because the runner does it by default for us already
    if (process.stdout.isTTY) {
      logErrors(error);
    }

    process.exit(1); // exit immediately whenever a task fails
  });
};

(async () => {
  try {
    console.log(''); // eslint-disable-line no-console
    await validate();
    console.log(''); // eslint-disable-line no-console
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
})();
