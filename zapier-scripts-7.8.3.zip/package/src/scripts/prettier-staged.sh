#!/usr/bin/env bash -e

# Stashes all unstaged files. Works even if you have staged/unstaged changes in the same file!
stash_unstaged () {
  # temp commit staged changes
  git commit -m "WIP" --no-verify --quiet

  git stash save --quiet $1

  # now un-commit the "WIP" commit:
  git reset --soft HEAD^
}

jsfiles=$(git diff --cached --name-only --diff-filter=ACMR | grep -E "\.(js|tsx?)$" | tr '\n' ' ')

# Only continue if there are *.js files staged
[ -z "$jsfiles" ] && exit 0

# Stash unstaged changes if there are any
unstaged_files=$(git diff --name-only)
if [[ -n "$unstaged_files" ]]; then
  stash_unstaged "prettier-temp"
  did_stash=1
else
  did_stash=0
fi

# Prettify all staged .js files
echo "💅 prettifying staged JS files.."
if [ -f ./node_modules/.bin/zapier-scripts ]; then
  echo "$jsfiles" | xargs node ./node_modules/.bin/zapier-scripts format
else
  # so we can dog-food prettier-staged while developing zapier-scripts!
  echo "$jsfiles" | xargs node src format
fi

# Add back the prettified files to staging
echo "$jsfiles" | xargs git add

# Pop the stashed unstaged changes after prettier runs. Might create merge conflicts but should be rare.
if [ "$did_stash" -eq "1" ]; then
  git stash pop --quiet
fi

exit 0
