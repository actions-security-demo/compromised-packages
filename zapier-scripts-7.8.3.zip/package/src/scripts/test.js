const isCi = require('is-ci');
const {
  doesFileExistInProject,
  executeWithTelemetry,
  getDefaultConfigFileForModule,
} = require('../utils');

const userArgs = process.argv.slice(2);

// FIXME(vitorbal): check `jest` attribute in `package.json`
const shouldUseBuiltInConfig =
  !userArgs.includes('--config') && !doesFileExistInProject('jest.config.js');

let config = shouldUseBuiltInConfig
  ? ['--config', getDefaultConfigFileForModule('jest')]
  : [];

if (isCi) {
  // Make sure jest knows it's running on CI, so it doesn't write snapshots etc.
  // See: https://jestjs.io/docs/en/cli#ci
  config = [...config, '--ci', '--no-colors'];
}

// Jest uses watchman under the hood, but we don't have a watchmanconfig
// TODO: add watchman config? Maybe it helps performance?
const args = [...config, ...userArgs, '--passWithNoTests', '--no-watchman'];

executeWithTelemetry('jest', args, {
  category: 'test',
  mechanism: 'zapier-script',
  processOptions: {
    env: {
      ...process.env,
      // Make sure Node use the UTC timezones to avoid discrepancies
      TZ: 'UTC',
    },
  },
});
