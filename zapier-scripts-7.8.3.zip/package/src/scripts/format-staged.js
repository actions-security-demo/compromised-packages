const { spawnSync } = require('child_process');
const path = require('path');

const result = spawnSync(path.join(__dirname, 'prettier-staged.sh'), [], {
  stdio: 'inherit',
});

process.exit(result.status);
