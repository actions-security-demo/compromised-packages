/*
 * Heavily inspired by:
 * https://github.com/kentcdodds/kcd-scripts/blob/master/src/scripts/lint.js
 */

const yargsParser = require('yargs-parser');
const isCi = require('is-ci');
const {
  doesFileExistInProject,
  executeWithTelemetry,
  getDefaultConfigFileForModule,
} = require('../utils');

let args = process.argv.slice(2);
const parsedArgs = yargsParser(args);

const shouldUseBuiltInConfig =
  !args.includes('--config') &&
  !doesFileExistInProject('.eslintrc') &&
  !doesFileExistInProject('.eslintrc.js') &&
  !doesFileExistInProject('.eslintrc.json');

let config = shouldUseBuiltInConfig
  ? ['--config', getDefaultConfigFileForModule('eslint')]
  : [];
// do not show colors when running in CI
if (isCi) {
  config = [...config, '--no-color'];
}

const filesGiven = parsedArgs._.length > 0;
if (filesGiven) {
  // we need to take all the flag-less arguments (the files that should be linted)
  // and filter out the ones that aren't js files. Otherwise json or css files
  // may be passed through
  args = args.filter(a => !parsedArgs._.includes(a) || a.endsWith('.js'));
}

// Make sure we wrap the glob between double quotes so we let ESLint expand the
// glob instead of the shell.
// By doing this we avoid the need to start a sub-shell when we invoke
// `zapier-scripts test` programmatically and we make sure the behavior is
// consistent across environments.
const filesGlob = '"{src/**/*,tests/**/*,*}.{js,ts,tsx}"';

executeWithTelemetry('eslint', [...config, ...args, filesGlob], {
  category: 'lint',
  mechanism: 'zapier-script',
});
