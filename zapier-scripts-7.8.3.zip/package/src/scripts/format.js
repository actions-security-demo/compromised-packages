const path = require('path');
const without = require('lodash.without');
const isCiEnvironment = require('is-ci');
const {
  doesFileExistInProject,
  executeWithTelemetry,
  getDefaultConfigFileForModule,
} = require('../utils');

const args = process.argv.slice(2);
const isCi = isCiEnvironment || args.includes('--ci');

const shouldUseBuiltInConfig =
  !args.includes('--config') &&
  !doesFileExistInProject('.prettierrc') &&
  !doesFileExistInProject('prettier.config.js');
const config = shouldUseBuiltInConfig
  ? ['--config', getDefaultConfigFileForModule('prettier')]
  : [];

const shouldUseBuiltInIgnoreFile =
  !args.includes('--ignore-path') && !doesFileExistInProject('.prettierignore');
const ignorePath = shouldUseBuiltInIgnoreFile
  ? ['--ignore-path', path.join(__dirname, '../config/.prettierignore')]
  : [];

const fileExts = ['js', 'ts', 'tsx', 'scss'];

let filesToApply = [];

// If we're in CI, and the `GIT_CHANGED_FILES` env variable exists,
// we will use it to only format the files that have changed on this branch.
// This speeds up the job in CI by a lot.
if (isCi && process.env.GIT_CHANGED_FILES) {
  const filesExtRegexp = new RegExp(`\\.(${fileExts.join('|')})$`);

  // The changed files list comes in this format:
  // `file1:file2:file3:`
  filesToApply = process.env.GIT_CHANGED_FILES.split(':').filter(
    // pretter errors if input files don't exist, even if they fall under an existing ignore
    // since this script only runs in the FE container (which doesn't have any files from web/backend),
    // any JS files would match the regex but not actually be available to format.
    f => filesExtRegexp.exec(f) && doesFileExistInProject(f)
  );

  // Early bail out if there are no files to process.
  // Prettier will display its usage if we don't pass any files to process.
  if (filesToApply.length === 0) {
    process.exit();
  }
} else {
  // The inner quotes make sure that Prettier expands the globs rather than the shell
  filesToApply = [`"{,**/}*.{${fileExts.join(',')}}"`];
}

executeWithTelemetry(
  'prettier',
  [
    ...config,
    ...ignorePath,
    isCi ? '--list-different' : '--write',
    ...without(args, '--ci'),
    ...filesToApply,
  ],
  {
    category: 'format',
    mechanism: 'zapier-script',
    processOptions: {
      stdio: 'inherit',
    },
  }
).then(exitCode => {
  if (isCi && exitCode > 0) {
    console.warn(
      'The files listed above have incorrect formatting. Run the `format` command to fix this.'
    );
  }
});
