module.exports = {
  trailingComma: 'es5',
  singleQuote: true,
  overrides: [
    {
      files: '*.yml',
      options: {
        singleQuote: false,
      },
    },
  ],
  arrowParens: 'avoid', // This was changed to 'always' in prettier 2.0.0
  endOfLine: 'auto', // This was changed to 'lf' in prettier 2.0.0
};
