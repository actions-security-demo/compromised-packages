module.exports = require('@zapier/babel-preset-zapier');
