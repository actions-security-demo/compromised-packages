module.exports = {
  plugins: ['@zapier/zapier'],
  extends: ['plugin:@zapier/zapier/config'],
  globals: {
    __filename: 'readonly',
    __dirname: false,
  },
  overrides: [
    {
      files: ['tests/**/*.js', '**/*.test.js'],
      env: { jest: true, jasmine: true },
    },
    {
      files: ['*.config*.js'],
      env: { node: true },
    },
  ],
};
