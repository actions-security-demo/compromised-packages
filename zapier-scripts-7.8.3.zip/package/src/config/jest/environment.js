const Enzyme = require('enzyme');
const Adapter = require('enzyme-adapter-react-16');
const registerRequireContextHook = require('babel-plugin-require-context-hook/register');

Enzyme.configure({ adapter: new Adapter() });

// Polyfill Webpack specific `require.context`
registerRequireContextHook();

// Avoid MaxListenersExceededWarning
process.setMaxListeners(0);

// Only mock cookies if we're in a browser environment
if (typeof window !== 'undefined') {
  Object.defineProperty(document, 'cookie', {
    get: function () {
      return this._value;
    },
    set: function (value) {
      this._value = value;
      return this._value;
    },
  });
}

global.localStorage = {
  getItem: () => {},
  setItem: () => {},
  removeItem: () => {},
  clear: () => {},
};

global.indexedDB = {
  open: () => ({}),
};

global.fetch = () =>
  Promise.resolve({
    status: 200,
  });

global.matchMedia = () => ({
  media: '',
  matches: false,
});
