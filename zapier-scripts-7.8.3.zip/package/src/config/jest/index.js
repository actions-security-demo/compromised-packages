const { getProjectDirectory } = require('../../utils');

// TODO(vitorbal): add coverage config
module.exports = {
  rootDir: getProjectDirectory(),
  testMatch: [
    '<rootDir>/tests/**/*.+(ts|tsx|js)',
    '<rootDir>/**/*.test.+(ts|tsx|js)',
  ],
  testPathIgnorePatterns: ['node_modules/', 'build/'],

  moduleNameMapper: {
    '\\.(css|scss)': require.resolve('./mocks/textMock'),
    '\\.svg': require.resolve('./mocks/svgMock'),
  },
  transform: {
    '\\.js$': 'babel-jest',
    '^.+\\.tsx?$': 'zapier-scripts/src/config/jest/transform.js',
    '\\.(gql|graphql)$': 'jest-transform-graphql',
  },
  transformIgnorePatterns: [
    // Ignore all node_modules except packages from `@zapier` org, because
    // some of those expose ES2015+ code that we should compile
    'node_modules/(?!(@zapier/.*)/)',
  ],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'json', 'node'],
  snapshotSerializers: ['enzyme-to-json/serializer'],
  setupFiles: ['raf/polyfill', require.resolve('./environment')],
  setupFilesAfterEnv: [
    '@testing-library/jest-dom/extend-expect', // Add some helpful assertions. See: https://testing-library.com/docs/ecosystem-jest-dom
    require.resolve('./jest-setup'),
  ],
  globals: {
    'ts-jest': {
      // https://github.com/kulshekhar/ts-jest/issues/805#issuecomment-456055213
      isolatedModules: true,
    },
  },
};
