const React = require('react');

const MockSvg = () => React.createElement('svg', { id: 'mock-svg' });

module.exports = MockSvg;
