// Jest/jsdom doesn't include these fetch-related globals by default.
const { Response, Request, Headers } = require('node-fetch');
global.Response = Response;
global.Headers = Headers;
global.Request = Request;

const fetchMock = require('fetch-mock');

global.beforeEach(() => {
  fetchMock.reset();
});
