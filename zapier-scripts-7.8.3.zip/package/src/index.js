#!/usr/bin/env node
const path = require('path');
const { spawnSync } = require('child_process');
const { getAvailableScripts } = require('./utils');

const attemptResolve = (...args) => {
  try {
    return require.resolve(...args);
  } catch (error) {
    return null;
  }
};

const [executor, , script, ...args] = process.argv;

// When ran without any args, print available scripts
if (!script && args.length === 0) {
  const availableScripts = getAvailableScripts()
    .map(s => `- ${s}`)
    .join('\n');

  console.info(`
Usage:
zapier-scripts [script] [args]

Available scripts:
${availableScripts}
`);

  process.exit(0);
}

const relativeScriptPath = path.join(__dirname, './scripts', script);
const scriptPath = attemptResolve(relativeScriptPath);

if (!scriptPath) {
  console.error(`Unknown script "${script}".`);
  process.exit(1);
}

const result = spawnSync(executor, [scriptPath, ...args], {
  stdio: 'inherit',
  env: process.env,
});

if (result.signal) {
  process.exit(1);
}

process.exit(result.status);
