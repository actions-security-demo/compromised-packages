const fs = require('fs');
const path = require('path');
const readPkgUp = require('read-pkg-up');
const telemetry = require('@zapier/telemetry');

const projectDirectory = path.dirname(readPkgUp.sync().path);

const doesFileExistInProject = file =>
  fs.existsSync(path.join(projectDirectory, file));

const getDefaultConfigFileForModule = moduleName =>
  require.resolve(`./config/${moduleName}`);

const getAvailableScripts = () => {
  const dir = path.join(__dirname, './scripts');
  return fs.readdirSync(dir).filter(name => {
    const stat = fs.statSync(path.join(dir, name));

    // Filter directories and non *.js files
    return stat.isFile() && path.extname(name) === '.js';
  });
};

const executeWithTelemetry = async (command, args, telemetryOptions) => {
  const { exitCode } = await telemetry.execute(command, args, {
    ...telemetryOptions,
  });

  // Tell the process to exit with the given error code.
  //
  // NOTE: The reason we're not using `process.exit` instead is because we want
  // to let remaining running handlers a chance to finish their execution.
  // In this use case, `telemetry.execute` needs some time to issue a request
  // to Sentry.
  process.exitCode = exitCode;

  return exitCode;
};

module.exports = {
  getProjectDirectory: () => projectDirectory,
  doesFileExistInProject,
  executeWithTelemetry,
  getDefaultConfigFileForModule,
  getAvailableScripts,
};
